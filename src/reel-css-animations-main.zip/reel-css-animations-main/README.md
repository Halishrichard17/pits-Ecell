
# CSS Animations

Awesome CSS Animations using Pure CSS😍

![Learn Web Developement by making projects (2)](https://user-images.githubusercontent.com/66505013/170861540-529d3053-793f-40f9-a9d7-5cfb485c316f.png)
